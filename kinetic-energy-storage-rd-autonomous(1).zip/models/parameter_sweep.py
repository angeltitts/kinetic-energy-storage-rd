from __future__ import annotations

import csv
import itertools
from pathlib import Path

from system_model import Material, Rotor, SystemMassModel, evaluate

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    rows: list[dict] = []

    strengths = [10, 15, 20, 25, 30, 40]
    fatigue = [0.4, 0.5, 0.6, 0.7]
    safety_factors = [1.25, 1.5, 2.0]
    radii = [0.25, 0.5, 1.0]
    containment = [0.25, 0.5, 0.75, 1.0, 1.5, 2.0]
    parasitic_scale = [0.5, 0.75, 1.0]

    for strength, fd, sf, radius, c, scale in itertools.product(
        strengths, fatigue, safety_factors, radii, containment, parasitic_scale
    ):
        material = Material(
            density_kg_m3=1500.0,
            tensile_strength_pa=strength * 1e9,
            fatigue_derating=fd,
            safety_factor=sf,
        )
        rotor = Rotor(mass_kg=50.0, radius_m=radius)
        masses = SystemMassModel(
            containment_ratio=c,
            vacuum_housing_ratio=0.15 * scale,
            stator_ratio=0.20 * scale,
            bearing_ratio=0.08 * scale,
            cryogenic_ratio=0.08 * scale,
            power_electronics_ratio=0.10 * scale,
            controls_ratio=0.03 * scale,
        )
        result = evaluate(material, rotor, masses)
        rows.append(
            {
                "strength_GPa": strength,
                "fatigue_derating": fd,
                "safety_factor": sf,
                "radius_m": radius,
                "containment_ratio": c,
                "other_parasitic_scale": scale,
                "effective_stress_GPa": result["effective_stress_GPa"],
                "tip_speed_m_s": result["tip_speed_m_s"],
                "rpm": result["rpm"],
                "rotor_Wh_kg": result["rotor_specific_energy_Wh_kg"],
                "system_Wh_kg": result["system_specific_energy_Wh_kg"],
                "stored_kWh": result["stored_energy_kWh"],
                "total_mass_kg": result["total_system_mass_kg"],
                "passes_500": result["passes_500_Wh_kg"],
            }
        )

    rows.sort(key=lambda row: row["system_Wh_kg"], reverse=True)

    out = ROOT / "results" / "phase0_sweep.csv"
    out.parent.mkdir(exist_ok=True)
    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)

    print(f"Wrote {len(rows)} cases to {out}")
    print("Best candidate:")
    for key, value in rows[0].items():
        print(f"{key}: {value}")

    baseline = [
        row for row in rows
        if row["strength_GPa"] == 20
        and row["fatigue_derating"] == 0.5
        and row["safety_factor"] == 1.5
    ]
    if baseline:
        best = max(baseline, key=lambda row: row["system_Wh_kg"])
        print("\nBest 20 GPa / 0.50 fatigue / 1.50 SF case:")
        for key, value in best.items():
            print(f"{key}: {value}")


if __name__ == "__main__":
    main()
