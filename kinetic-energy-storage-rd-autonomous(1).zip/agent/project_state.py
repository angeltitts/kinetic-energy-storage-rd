from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


STATE_FILES = [
    "PROJECT_BRIEF.md",
    "REQUIREMENTS.md",
    "ASSUMPTIONS.md",
    "OPEN_QUESTIONS.md",
    "DECISION_LOG.md",
    "AGENT_CHARTER.md",
    "CONFIDENCE_REGISTER.csv",
]


@dataclass
class ProjectState:
    text: str

    @classmethod
    def load(cls) -> "ProjectState":
        blocks: list[str] = []
        for rel in STATE_FILES:
            path = ROOT / rel
            if not path.exists():
                blocks.append(f"\n## {rel}\n[MISSING]\n")
                continue
            blocks.append(f"\n## {rel}\n{path.read_text(encoding='utf-8')}\n")

        baseline = ROOT / "results" / "baseline.json"
        if baseline.exists():
            blocks.append(
                "\n## results/baseline.json\n"
                + baseline.read_text(encoding="utf-8")
                + "\n"
            )

        latest = ROOT / "results" / "latest_agent_report.md"
        if latest.exists():
            blocks.append(
                "\n## results/latest_agent_report.md\n"
                + latest.read_text(encoding="utf-8")
                + "\n"
            )

        return cls(text="\n".join(blocks))
