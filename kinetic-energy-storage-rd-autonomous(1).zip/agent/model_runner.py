from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run_models() -> str:
    system_model = ROOT / "models" / "system_model.py"
    sweep_model = ROOT / "models" / "parameter_sweep.py"

    if not system_model.exists():
        return "system_model.py missing."

    baseline_proc = subprocess.run(
        [sys.executable, str(system_model)],
        capture_output=True,
        text=True,
        check=True,
        cwd=str(ROOT / "models"),
    )

    sweep_text = ""
    if sweep_model.exists():
        sweep_proc = subprocess.run(
            [sys.executable, str(sweep_model)],
            capture_output=True,
            text=True,
            check=True,
            cwd=str(ROOT / "models"),
        )
        sweep_text = "\n\nPARAMETER SWEEP\n" + sweep_proc.stdout[-8000:]

    baseline_json = ROOT / "results" / "baseline.json"
    baseline = ""
    if baseline_json.exists():
        baseline = baseline_json.read_text(encoding="utf-8")

    return (
        "BASELINE MODEL STDOUT\n"
        + baseline_proc.stdout[-8000:]
        + "\n\nBASELINE JSON\n"
        + baseline[-8000:]
        + sweep_text
    )
