# Research Data

Research agents should extract structured engineering evidence rather than
storing narrative summaries only.

For every source, capture where applicable:

- source title
- DOI / URL
- publication date
- experiment vs model
- material/process
- tensile strength
- density
- gauge length
- strain to failure
- fatigue cycles and stress ratio
- creep conditions
- rotor tip speed / RPM / radius
- bearing type
- vacuum level
- measured losses
- containment mass
- failure mode
- confidence / caveats

Never mix theoretical single-fiber strength with demonstrated macroscale
structural strength without an explicit scale qualifier.
