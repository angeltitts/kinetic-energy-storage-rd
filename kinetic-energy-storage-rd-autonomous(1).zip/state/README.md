# Agent State

This directory is reserved for machine-readable autonomous-agent state.

Do not use it as a substitute for the human-readable source-of-truth files in
the repository root. The authoritative engineering record remains:

- PROJECT_BRIEF.md
- REQUIREMENTS.md
- ASSUMPTIONS.md
- OPEN_QUESTIONS.md
- DECISION_LOG.md
- CONFIDENCE_REGISTER.csv
